package com.DO.Servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.DO.dao.RegisterUserDao;
import com.DO.model.RegisterUser;

/**
 * Servlet implementation class RegisterUserController
 */

public class RegisterUserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterUserController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String UserID=request.getParameter("UserID");
		String Name=request.getParameter("Name");
		String Joingdate=request.getParameter("Joingdate");
		String Password=request.getParameter("password");
		String role=request.getParameter("role");
		String zipcode=request.getParameter("zip");
		String city = request.getParameter("city");
		
		RegisterUser r1=new RegisterUser(UserID,Name,Joingdate,Password,role,zipcode,city);
		
		RegisterUserDao d1=new RegisterUserDao();
		
		String result = d1.insert(r1);
		response.getWriter().print(result);
		RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
		rd.forward(request, response);
		
		
	}

}
