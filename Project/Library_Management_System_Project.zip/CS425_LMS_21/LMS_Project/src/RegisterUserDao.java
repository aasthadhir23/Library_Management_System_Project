package com.DO.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.DO.model.RegisterUser;

public class RegisterUserDao {
	 final String url = "jdbc:postgresql://0.0.0.0:5432/LMS";
		final String user = "postgres";
		final String password = "0256"; //"<add your password>";
		
		
				private String dbDriver = "org.postgresql.Driver";
					
					public void loadDriver(String dbDriver)
					{
						try {
							Class.forName(dbDriver);
						} catch (ClassNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					public Connection getConnection()
					{
						Connection con = null;
						try {
							con = DriverManager.getConnection(url, user, password);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return con;
					}
					
					
					public String insert(RegisterUser r1)
					{
						loadDriver(dbDriver);
						Connection con = getConnection();
					//	String result = "Data entered successfully";
						String sql = "insert into users values(?,?,?,?,?,?,?)";
						
						try {
						PreparedStatement ps = con.prepareStatement(sql);
						ps.setString(1, r1.getUserID());
						ps.setString(2, r1.getName());
						ps.setDate(3, java.sql.Date.valueOf(r1.getJoingdate()));
						ps.setString(4, r1.getPassword());
						ps.setString(5, r1.getRole());
						ps.setString(6, r1.getZipcode());
						ps.setString(7, r1.getCity());
						
						int rs = ps.executeUpdate();   
						
			            if(rs!=0) {
			            	return "User created";
			            }
			           
			       }catch (SQLException e) {
			    	   
			    		 System.out.println(e.getMessage());
			       }
					return "Not created";
					
						
					}

				}

